package com.fariyatulaeni.footballmatchschedule.model

data class TeamsItem(val strTeamBadge: String?)
