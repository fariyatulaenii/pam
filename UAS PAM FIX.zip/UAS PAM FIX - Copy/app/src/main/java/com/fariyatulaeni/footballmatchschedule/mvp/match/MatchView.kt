package com.fariyatulaeni.footballmatchschedule.mvp.match

import com.fariyatulaeni.footballmatchschedule.model.EventsItem
import com.fariyatulaeni.footballmatchschedule.model.LeagueResponse

interface MatchView {

    fun showLoading()
    fun hideLoading()
    fun showEmptyData()
    fun showLeagueList(data: LeagueResponse)
    fun showEventList(data: List<EventsItem>)
}
