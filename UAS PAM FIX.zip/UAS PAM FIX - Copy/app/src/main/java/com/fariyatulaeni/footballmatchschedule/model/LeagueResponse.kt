package com.fariyatulaeni.footballmatchschedule.model

data class LeagueResponse(val leagues: List<LeaguesItem>?)
