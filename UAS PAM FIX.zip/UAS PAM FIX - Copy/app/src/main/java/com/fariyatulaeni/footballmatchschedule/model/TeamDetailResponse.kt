package com.fariyatulaeni.footballmatchschedule.model

data class TeamDetailResponse(val teams: List<TeamsItem>?)
