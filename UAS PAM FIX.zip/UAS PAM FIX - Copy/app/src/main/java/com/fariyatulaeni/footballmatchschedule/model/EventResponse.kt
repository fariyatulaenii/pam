package com.fariyatulaeni.footballmatchschedule.model

data class EventResponse(val events: List<EventsItem>?)
